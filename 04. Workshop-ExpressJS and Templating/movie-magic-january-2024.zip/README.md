# movie-magic-january-2024
JS Backend Workshop @SoftUni
